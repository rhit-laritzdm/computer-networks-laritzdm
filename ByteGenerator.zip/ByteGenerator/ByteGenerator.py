import sys

if __name__ == '__main__':
    numBytes = int(sys.argv[1])
    numPerSequence = 1;
    if(len(sys.argv) > 2):
        numPerSequence = int(sys.argv[2]);

    firstAsciiLetter = 97; #ASCII value of letter 'a'
    lastAsciiLetter = 122; #ASCII value of letter 'z'
    curCount = 0;
    letterIndex = 0;
    rounds = 0;
    prevA = False;
    i = 0;
    while(i < numBytes):
        tempChar = '\0';
        if(curCount >= numPerSequence):
            letterIndex += 1;
            curCount = 0;

        tempChar = chr((letterIndex%(lastAsciiLetter-firstAsciiLetter+1))+firstAsciiLetter);

        if(tempChar == 'a' and not prevA):
            rounds += 1;
            print(rounds, end ="");
            s = str(rounds);
            i += len(s);
            prevA = True;
        elif(tempChar != 'a'):
            prevA = False;

        print(tempChar, end ="");

        curCount += 1;
        i += 1;

    print("\n");
