
public class ByteGenerator {

	public static void main(String[] args) {
		
		int numBytes = Integer.parseInt(args[0]);
		int numPerSequence = 1;
		if(args.length > 1) {
			numPerSequence = Integer.parseInt(args[1]);
		}
		
		int firstAsciiLetter = 97; //ASCII value of letter 'a'
		int lastAsciiLetter = 122; //ASCII value of letter 'z'
		int curCount = 0;
		int letterIndex = 0;
		int rounds = 0;
		boolean prevA = false;
		for (int i = 0; i < numBytes; i++) { 
			char tempChar;
			if(curCount >= numPerSequence) {
				letterIndex++;
				curCount = 0;
			}
			tempChar = (char) ((letterIndex%(lastAsciiLetter-firstAsciiLetter+1))+firstAsciiLetter);
			
			if(tempChar == 'a' && !prevA) {
				rounds++;
				System.out.print(rounds);
				String s = "" + rounds;
				i += s.length();
				prevA = true;
			} else if(tempChar != 'a') {
				prevA = false;
			}
			System.out.print(tempChar);
			
			curCount++;
		}
		
		System.out.println("\n");
	}

}
