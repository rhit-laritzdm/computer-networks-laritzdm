For your various labs, I have made a byte generator that produces and prints a message that contains the number of bytes specified when running the code.  The message is a numbered sequence of letters from a-z, and simply repeats letters a-z until the desired number of bytes has been printed.  In this way, you can create messages of a precise length to test your system.

I have provided the same program in 3 different languages for your convenience.  Use whichever one you wish, they all do the same thing.

For the Java version, you can compile and run the program on the command line using the following commands:
	javac ByteGenerator.java
	java ByteGenerator X <Y>
(X and optional Y explained below with examples)

For the python version, you can simply run it using the following command:
	python ByteGenerator.py X <Y>
(X and optional Y explained below with examples)

For the C version, you can compile and run the program using the following commands:
	gcc ByteGenerator.c -o ByteGenerator
	./ByteGenerator X <Y>
(X and optional Y explained below with examples)

Note that running these programs simply results in the specified number of bytes being printed to the console.  You can then copy-and-paste the whole string as input to your socket programs to test the various lengths of the messages.

If you wish to have the output go to a file, you can use the UNIX command option '>' to port the output to a file.  If you wish to output to a file named output.txt, the commands would be as follows:
	C - ./ByteGenerator X Y > output.txt
	Python - python ByteGenerator.py X Y > output.txt
	Java - java ByteGenerator X Y > output.txt
	


Command line arguments X and optional Y:
The program (in any of the three languages) requires one argument and a second argument is optional.  They are explained below with examples:

	X - The number of bytes to generate.  The string generated will be exactly X bytes and will be of the form (by default, using argument Y changes the string a bit) "1abcdefghijklmnopqrstuvwxyz2abc..."  That is, each sequence of a-z (all lower case) is prefaced with a sequence number indicating the current number of the sequence.  Each time the sequence of letters starts over, a number is first given indicating the nth sequence.  This number is also accounted for in the number of bytes generated.  These numbers help track the precise number of bytes.  That is, if there is the string "1abc...2abc...3abc...", the number of total bytes is 26*3+3 -- (26*3 for the three sequences of a-z and +3 for the three bytes of the digits printed '1', '2' and '3').  If you pass in the argument of 500 for X, then there will be exactly 500 bytes printed, which includes the sequence of letters and the digits printed indicating the number of times the sequence has occurred.

To run the programs above, if you wish 500 bytes, you can use the following commands:
	C - ./ByteGenerator 500
	Python - python ByteGenerator.py 500
	Java - java ByteGenerator 500

	Y - When NOT included, the default for this value is 1.  This number is used to determine how many of each letter is repeated in one sequence.  With the default of 1 for this, the sequence looks like "1abcdefg...2abcdefg...".  When greater than 1, this number indicates to repeat each letter Y times.  So, for example, if the value of 2 was given for the Y argument, the string would print as "1aabbccddeeffgg...2aabbccdd...".  If a value of 5 is given for Y, the sequence would appear as "1aaaaabbbbbcccccdddddeeeee...2aaaaabbbbbccccc...3aaaaa..."

To run the programs above, if you wish to have each letter repeated 3 times and want 1024 bytes, you can use the following commands:
	C - ./ByteGenerator 1024 3
	Python - python ByteGenerator.py 1024 3
	Java - java ByteGenerator 1024 3
